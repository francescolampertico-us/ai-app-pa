# Antigravity Build Prompt - V2

Use the attached package as the single source of truth for the congressional hearing memo tool.

Important:
- the submitted Mercury-style memo is now the canonical output family
- do not build a generic summarizer
- do not invent new headings or restructure Q&A by topic unless the repo explicitly says so

Build a V1.1 prototype that does the following:
1. accepts transcript or hearing-source text plus metadata
2. normalizes noisy source text
3. extracts a structured hearing record
4. composes a memo that matches the package style rules
5. runs verification and surfaces flags separately
6. exports a clean docx with support for page footer rendering

Implementation priorities:
- exact top-level heading control
- correct speaker-label formatting
- high-level overview generation
- member-by-member Q&A routing
- chair closing folded into the chair subsection
- single confidentiality line in content, repeatable as page footer in export

Do not improvise architecture decisions that conflict with the repo files.
If anything is ambiguous, prefer the style guide and changelog over generic summarization instincts.
