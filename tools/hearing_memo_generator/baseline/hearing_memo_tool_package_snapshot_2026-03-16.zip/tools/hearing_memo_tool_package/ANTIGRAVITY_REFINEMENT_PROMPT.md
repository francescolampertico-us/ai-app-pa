# Antigravity Refinement Prompt - Tighten the Hearing Memo Prototype

Use this after the first prototype exists.

---

Refine the existing **Congressional Hearing Memo Generator** prototype.
Do not rebuild from scratch.
Work from the current implementation and the repo package documents.

## Primary objective

Improve reliability, structure adherence, and reviewability.
Focus on making the tool behave more like a production-grade internal workflow and less like a generic summarizer.

## Source of truth

The repo files remain authoritative:
- `IMPLEMENTATION_PLAN.md`
- `STYLE_GUIDE.md`
- `RISK_POLICY.md`
- `AGENT_BOUNDARIES.md`
- `tool.yaml`
- `skill.md`
- schemas
- prompts
- eval docs

Do not rewrite the product definition unless necessary.

## Refinement priorities

### 1. Better normalization
Improve handling of:
- messy speaker labels
- repeated honorifics
- OCR noise
- duplicated lines
- bad paragraph breaks
- panel boundaries

### 2. Better heading routing
Make heading selection more reliable based on hearing structure.
Support the approved heading family only.

### 3. Better Q&A clustering
Condense long question-and-answer sections into issue clusters instead of near-transcript recap.
Remove procedural filler.
Preserve major disputes, recommendations, and commitments.

### 4. Better verification
Add or tighten checks for:
- header/body date mismatch
- title mismatch
- missing affiliations
- unsupported significance claims
- empty or weak mandatory sections
- memo/schema validation failures

### 5. Better export quality
If not already implemented, add clean export to markdown and a reasonably formatted DOCX.
If DOCX export is added, keep formatting simple and professional.

### 6. Better reviewer experience
Make it easier to compare:
- extracted record
- final memo text
- verification findings

## Constraints

- keep the pipeline modular
- do not collapse stages into a single opaque call
- do not add unnecessary complexity
- do not add features unrelated to memo quality

## Delivery request

Please:
1. audit the current implementation against the repo docs
2. list the highest-priority gaps
3. implement the highest-value fixes first
4. explain exactly what changed
5. identify any remaining weak points
