# Test Cases - Recommended V1.1 Suite

## Case 1 - Mercury-style standard committee hearing
Goal:
- verify the default memo family
- verify long-form SUBJECT line
- verify overview stays high level

## Case 2 - Co-chair or commission hearing
Goal:
- verify routing to `Co-Chairs Opening Remarks`
- verify speaker-label differences are intentional and controlled

## Case 3 - Witness headings with honorifics and affiliations
Goal:
- verify witness subsection headings preserve the submitted memo's naming style
- verify no guessed affiliations

## Case 4 - Chair closing folded into Q&A
Goal:
- ensure material closing remarks remain inside the chair subsection
- ensure no separate `Closing Remarks` top-level section appears by default

## Case 5 - Header/body date mismatch
Goal:
- ensure verification flags memo-date or hearing-date inconsistencies
- ensure day-of-week is checked as well as numeric date

## Case 6 - Noisy transcript
Goal:
- verify speaker normalization and paragraph cleanup
- ensure the output still reads like a memo rather than a transcript

## Case 7 - Over-detailed overview
Goal:
- ensure the verifier catches overviews that mention too many people, exchanges, or granular details

## Case 8 - Q&A routed by issue instead of member
Goal:
- ensure verifier flags the wrong organization pattern for this memo family

## Case 9 - Footer formatting
Goal:
- ensure memo text contains the confidentiality line once
- ensure repeated page footers are left to the export layer

## Case 10 - Strong witness claims
Goal:
- ensure attribution remains explicit and the memo does not transform testimony into unqualified fact
